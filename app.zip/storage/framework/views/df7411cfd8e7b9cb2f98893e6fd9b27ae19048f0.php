
<?php $__env->startSection('title', 'Sign Up'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('/utils/Nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">

    <div class="row">
        <div class="col-lg-3 col-sm-12 col-xm-12">

        </div>
        <div class="col-lg-6 col-sm-12 col-xm-12">

        <div class="before_form">
        <div class="form_container">
            <div class="form_body">
                <form action="/register" method="POST" >
                    <?php echo csrf_field(); ?>
                    <div class="form_cont_holder">
                      <div class='tittle'>Sign Up</div>
                        <input class="form-control" name='first_name'  value="<?php echo e(old('first_name')); ?>" placeholder='First Name' type='text'/>
                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form_cont_holder">
                    
                        <input class="form-control" name='last_name'  value="<?php echo e(old('last_name')); ?>" placeholder='Last Name' type='text' />
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form_cont_holder">
                        <input class="form-control" name='email'  value="<?php echo e(old('email')); ?>" placeholder='Email' type='email' />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class='alert alert-danger'><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form_cont_holder">
                        <input class="form-control" name='password'  value="<?php echo e(old('password')); ?>" placeholder='password' type='password' />
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <br /><br />
                
                <button type="submit" class='but'>Sign Up</button>

                <hr />
                
                <div class='route'>Already Have An Account? <a href='/login'>Login</a></div>
                </form>
            </div>
        </div> 
        </div>

        </div>
        <div class="col-lg-3 col-sm-12 col-xm-12">

        </div>
    </div> 

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fiko\resources\views/signup.blade.php ENDPATH**/ ?>