
<?php $__env->startSection('title', 'Payment Schedule'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="dashboard">
        <div class='row'>
            <div class='col-lg-3 col-md-12 col-sm-12'>
                
                   
            </div>

            <div class='col-lg-6 col-md-12 col-sm-12'>
                     <?php if(session()->has('msg')): ?>
                            <p class='goodmsg'><?php echo e(session('msg')); ?></p>
                      <?php endif; ?>
                  
                   
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->plan_id): ?>
                         <img src="<?php echo e(asset('/assets/img/favicon.png')); ?>" />
                           <p>Hi <?php echo e(auth()->user()->first_name); ?> Kindly  See Your Payment Schedule for Your Goal <?php echo e(auth()->user()->goal); ?> </p>
                            <table class='table'>
                                <tr>
                                    <th>Sn</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                </tr>      
                                  <?php
                                    if(auth()->user()->freq == 7){
                                        $freq = 7;
                                       
                                    }elseif(auth()->user()->freq == 30){
                                        $freq = 30;
                                       
                                    }
                                  ?>

                                <?php for($i = 1; $i <=auth()->user()->no_payment; $i++): ?>
                                            <?php
                                            $start_date = auth()->user()->start;
                                             $next_interval = ($i -1) * $freq;
                                             $newDate = date('Y-m-d',strtotime($start_date.'+ '.$next_interval.' days'));
                                            ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td>Payment for goal <?php echo e(auth()->user()->goal); ?></td>
                                        <td>
                                           <?php echo e($newDate); ?>

                                        </td>
                                        <td><?php echo e(auth()->user()->single_payment); ?></td>
                                    </tr>
                                <?php endfor; ?>
                            </table>

                                <form action="/getpdf" method="get">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="but">Send PDF</button>
                                </form>
                                <a href='/dashboard'>Dashboard</a> 
                            <?php else: ?>
                                <p>You have no Current Goal Please click <a href='/create_goal'>here</a> to start a plan</p>
                            
                        <?php endif; ?>

                      
                    <?php endif; ?>
                 
            </div>

            <div class='col-lg-3 col-md-12 col-sm-12'>
                
                   
            </div>
        </div>

    </div>
</div>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fiko\resources\views//schedule.blade.php ENDPATH**/ ?>