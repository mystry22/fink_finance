
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('/utils/Nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">

    <div class="row">
        <div class="col-lg-3 col-sm-12 col-xm-12">

        </div>
        <div class="col-lg-6 col-sm-12 col-xm-12">

        <div class="before_form">
        <div class="form_container">
            <div class="form_body">
                <form action="/authe" method="POST" >
                    <?php echo csrf_field(); ?>

                    <div class="form_cont_holder">
                        <div class='tittle'>Login</div>
                        
                        <input type="text" name="email" class="form-control" id="name" value="<?php echo e(old('email')); ?>" placeholder='Email' required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form_cont_holder">
                        
                        <input type="password" class="form-control" name="password" id="pass" value="<?php echo e(old('password')); ?>" placeholder='Password' required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <br /> 
                    <br />
                
                  <button type="submit" class='but'>Login</button>
                  <hr />
                  <div class='route'>Don't Have An Account? <a href='/signup'>Signup</a></div>
                </form>
            </div>
        </div> 
        </div>

        </div>
        <div class="col-lg-3 col-sm-12 col-xm-12">

        </div>
    </div> 

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fiko\resources\views/login.blade.php ENDPATH**/ ?>