
<?php $__env->startSection('title', 'Create A Goal'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('/utils/Nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">

    <div class="row">
        <div class="col-lg-3 col-sm-12 col-xm-12">

        </div>
        <div class="col-lg-6 col-sm-12 col-xm-12">

        <div class="before_form">
        <div class="form_container">
            <div class="form_body">
                <form action="/create_new_goal" method="POST" >
                    <?php echo csrf_field(); ?>
                    
                    <div class="form_cont_holder">
                      <div class='tittle'>Set Up A Goal</div>
                      <?php if(session()->has('err_msg')): ?>
                            <p class='errmsg'><?php echo e(session('err_msg')); ?></p>
                      <?php endif; ?>
                        <input class="form-control" name='goal_name'  value="<?php echo e(old('goal_name')); ?>" placeholder='Goal Name' type='text' required/>
                        <?php $__errorArgs = ['goal_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class='errmsg'><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form_cont_holder">
                    
                        <input class="form-control" name='amount'  value="<?php echo e(old('amount')); ?>" placeholder='Amount' type='number' required />
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class='errmsg'><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form_cont_holder">
                        <label>Start Date</label>
                        <input class="form-control" name='start'  value="<?php echo e(old('start')); ?>"  type='date' required />
                        <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class='errmsg'><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>
                    <div class="form_cont_holder">
                        <label>End Date</label>
                        <input class="form-control" name='end'  value="<?php echo e(old('start')); ?>"  type='date' required />
                        <?php $__errorArgs = ['end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class='errmsg'><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form_cont_holder" required>
                        <select name="freq" class="form-control">
                            <option value="">Select Frequency</option>
                            <option value="7">Weekly</option>
                            <option value="30">Monthly</option>
                        </select>
                    </div>

                        <?php $__errorArgs = ['freq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class='errmsg'><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                   
                    <br /><br />
                
                <button type="submit" class='but'>Create Goal</button>

                <hr />
                
                
                </form>
            </div>
        </div> 
        </div>

        </div>
        <div class="col-lg-3 col-sm-12 col-xm-12">

        </div>
    </div> 

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fiko\resources\views/goal.blade.php ENDPATH**/ ?>