## Fink_Finance

This show the demonstration of a finance app that helps users plan their savings 

## Ops

Here users register and and choose a goal they are saving for,
after creating a goal users can get the pdf format of their saving plan to their email
and will also get notification when due for payment using the command feature